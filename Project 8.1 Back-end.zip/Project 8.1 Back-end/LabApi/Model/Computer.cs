namespace LabModel
{
    public class Computer
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? Specs { get; set; }
        public DateTime Datetime { get; set; }
        private bool _isBooked;
        public enum StatusList
        {
            Avaiable,
            Maintenance,
            OutOfOrder,
            Removed,
            Reserved,
            InUsing,
        }
        public StatusList Status { get; set; }
        public List<Software> Softwares { get; set; }
        public Computer(string Name, string Description, string Specs, StatusList Status, bool IsBooked, DateTime Datetime)
        {
            this.Name = Name;
            this.Description = Description;
            this.Specs = Specs;
            this.Datetime = Datetime;
            if (Id == null) Id = ValidateId();
            Softwares = new();
            this.Status = Status;
            this.IsBooked = IsBooked;
        }
        public bool IsBooked
        {
            get { return _isBooked; }
            private set
            {
                _isBooked = value;
            }
        }
        private string? CreateId()
        {
            string CharName = Name.Substring(0, 2);
            string CharDescription = Description.Substring(0, 2);
            string CharSpecs = Specs.Substring(0, 2);
            string DateMonth = Datetime.Month.ToString();
            string DateToday = Datetime.Day.ToString();
            return CharName + CharDescription + CharSpecs + DateMonth + DateToday;
        }
        public string? ValidateId()
        {
            return CreateId().ToUpper();
        }
        public void addSoftware(Software software)
        {
            Softwares.Add(software);
        }
        public override string ToString()
        {
            return $"Name: {Name}, Description: {Description}, Specs: {Specs}, Datetime: {Datetime}";
        }
    }
}