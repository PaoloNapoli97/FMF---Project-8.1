namespace ComputerDTO
{
    public class BookingAddDTO
    {
        public string? UserId {get; set;}
        public string? Day {get; set;}
        public string? Hour {get; set;}
    }
}