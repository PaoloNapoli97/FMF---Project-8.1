namespace UserPatchDto
{
    public class UserStatusDTO
    {
        public bool Status {get; set;}
    }
}