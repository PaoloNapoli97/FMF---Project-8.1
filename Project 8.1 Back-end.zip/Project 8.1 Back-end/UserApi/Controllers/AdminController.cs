using Microsoft.AspNetCore.Mvc;
using UserServices;
using UserModel;

namespace UserApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class AdminController : ControllerBase
    {
        UserService userService = new();

        [HttpGet]
        [Route("Admin/GetAll/Users")]
        public ActionResult<List<User>> GetUsers()
        {
            userService.CreateUserDb();
            return Ok(userService.ReadUsers());
        }

        [HttpGet]
        [Route("{Id}")]
        public ActionResult<User> GetUserById(string Id)
        {
            userService.ReadUsers();
            var user = userService.ReadUserById(Id);
            return user == null ? NotFound() : Ok(user);
        }


        [HttpPost]
        [Route("CreateUser{Id}+{Name}+{Password}")]
        public ActionResult PostUser(string Id, string Name, string Password, bool Status, User.RoleList Role)
        {
            userService.ReadUsers();
            var checkIfExist = userService.ReadUserById(Id);
            if (checkIfExist != null)
            {
                return BadRequest("Id not unique, unable to add user");
            }
            else
            {
                User user = new User(Id, Name, Password, Status, Role);
                userService.ReadUsers().Add(user);
                var pathToUrl = Request.Path.ToString() + '/' + user.Id;
                userService.WriteUsers();
                return Created(pathToUrl, user);
            }
        }

        [HttpPut]
        [Route("{Id}/Replace/User")]
        public ActionResult PutUser(string Id, User user)
        {
            userService.ReadUsers();
            var editUser = userService.ReadUserById(Id);
            if (editUser == null)
            {
                return BadRequest("User was not found");
            }
            else
            {
                editUser.Id = user.Id;
                editUser.Name = user.Name;
                editUser.Role = user.Role;
                userService.WriteUsers();
                return Ok(editUser);
            }
        }

        [HttpPatch]
        [Route("{Id}/Edit/User")]
        public ActionResult PatchUser(string Id, string NewId, string NewName, User.RoleList role)
        {
            userService.ReadUsers();
            var editUser = userService.ReadUserById(Id);
            if (editUser == null)
            {
                return BadRequest("User was not found");
            }
            else
            {
                editUser.Id = NewId;
                editUser.Name = NewName;
                editUser.Role = role;
                userService.WriteUsers();
                return Ok(editUser);
            }
        }

        [HttpPatch]
        [Route("{Id}/ChangeStatus")]
        public ActionResult PatchUserStatus(string Id, bool Status)
        {
            userService.ReadUsers();
            var editUser = userService.ReadUserById(Id);
            if (editUser == null)
            {
                return BadRequest("User was not found");
            }
            else
            {
                editUser.EditIsEnable(Status);
                userService.WriteUsers();
                return Ok(editUser);
            }
        }

    }
}
