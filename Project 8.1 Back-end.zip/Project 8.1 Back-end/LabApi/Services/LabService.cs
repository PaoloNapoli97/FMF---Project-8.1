using FileManager.Controller;
using LabModel;

namespace LabServices
{
 public class LabService
 {
    private const string LabDb = "LabDb.json"; 
    FileManagers fileManager = new();
    private List<Lab> labs = new();
    private List<Computer> computers = new();
    public void CreateLabDb(){
        fileManager.CreateFile<Lab>(LabDb);
    }
    public void WriteLabs(){
        fileManager.WriteItems(labs, LabDb);
    }
    public List<Lab> ReadLabs()
    {
        labs = fileManager.ReadItems<Lab>(LabDb);
        return labs;
    }
    public Lab? ReadLabById(string Id)
    {
        return labs.Find(x => x.Id == Id);
    }
 }   
}