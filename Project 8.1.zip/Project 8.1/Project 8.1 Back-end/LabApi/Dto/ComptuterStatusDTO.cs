using LabModel;

namespace ComputerDTO {
    public class ComptuterStatusDTO
    {
        public Computer.StatusList StatusList {get; set;}
    }
}