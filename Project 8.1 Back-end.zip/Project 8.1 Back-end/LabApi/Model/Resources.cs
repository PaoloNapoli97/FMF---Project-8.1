namespace LabModel
{
    public class Resources
    {
        public string? Id;
    }
}