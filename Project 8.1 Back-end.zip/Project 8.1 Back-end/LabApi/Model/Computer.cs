namespace LabModel
{
    public class Computer
    {
        public string? Id = null;
        public string? Name {get; set;}
        public string? Description {get; set;}
        public string? Specs {get; set;}
        public DateTime dateTime;
        
        public Computer(string Name, string Description, string Specs, DateTime dateTime){
            this.Name = Name;
            this.Description = Description;
            this.Specs = Specs;
            dateTime = DateTime.Now;
            ValidateId();
        }
        private enum _status
        {
            Avaiable,
            Maintenance,
            OutOfOrder,
            Removed,
            Reserved,
            InUsing,
        }
        private List<Software> _softwares {get; set;} 
        private bool IsBooked {get; set;}

        public string? CreateId(){
            string CharName = Name.Substring(0, 2);
            string CharDescription = Description.Substring(0, 2);
            string CharSpecs = Specs.Substring(0, 2);
            string DateMonth = dateTime.Month.ToString();
            string DateToday = dateTime.Day.ToString();
            return CharName + CharDescription + CharSpecs + DateMonth + DateToday;
        }

        public string? ValidateId(){
            return Id = CreateId();
        }
     }
}