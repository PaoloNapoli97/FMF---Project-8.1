namespace LabModel
{
    public class Resources
    {
        public string? Name {get; set;}
        public string? Description {get; set;}
        public Resources(string Name, string Description){
            this.Name = Name;
            this.Description = Description;
        }
    }
}