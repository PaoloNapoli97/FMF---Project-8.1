using Microsoft.AspNetCore.Mvc;
using LabModel;
using LabServices;


namespace LabApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class LabController : ControllerBase
    {
        LabService labService = new();

        [HttpGet]
        [Route("GetAllLabs")]
        public ActionResult<List<Lab>> GetLabs()
        {
            labService.CreateLabDb();
            return Ok(labService.ReadLabs());
        }

        [HttpPost]
        [Route("AddLab")]
        public ActionResult PostLab(string LabId)
        {
            labService.ReadLabs();
            var checkIfExist = labService.ReadLabById(LabId);
            if (checkIfExist != null)
            {
                return BadRequest("Lab Id doen't exist");
            }
            else
            {
                Lab lab = new Lab(LabId);
                labService.ReadLabs().Add(lab);
                var pathToUrl = Request.Path.ToString() + '/' + lab.Id;
                labService.WriteLabs();
                return Created(pathToUrl, lab);
            }
        }

        [HttpPost]
        [Route("{LabId}/AddComputer{Name}+{Description}+{Specs}")]
        public ActionResult PostComputer(string LabId, string Name, string Description, string Specs)
        {
            labService.ReadLabs();
            var checkIfExist = labService.ReadLabById(LabId);
            if (checkIfExist == null)
            {
                return BadRequest("Lab Id doen't exist");
            }
            else
            {
                Computer computer = new Computer(Name, Description, Specs, DateTime.Now);
                checkIfExist._computers.Add(computer);
                var pathToUrl = Request.Path.ToString() + '/' + checkIfExist.Id;
                labService.WriteLabs();
                return Created(pathToUrl, computer);
            }
        }
    }
}
