public class Token
{
    public string? UserId {get; set;}
    public Guid Guid {get; set;}

    public Token(string UserId){
        this.UserId = UserId;
        Guid = Guid.NewGuid();
    }
}