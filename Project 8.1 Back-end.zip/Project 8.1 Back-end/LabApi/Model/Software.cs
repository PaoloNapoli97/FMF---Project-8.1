namespace LabModel
{
    public class Software
    {
        public string? name {get; set;}
    }
}