using BookingModel;
using BookingServices;
using Microsoft.AspNetCore.Mvc;

namespace BookingApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class BookingController : ControllerBase
    {
        BookingService bookingService = new();

        [HttpGet]
        [Route("")]
        public ActionResult<List<Booking>> GetBooking(){
            var bookings = bookingService.ReadBookings();
            return Ok(bookings);
        }
    }
}