namespace ComputerDTO
{
    public class ResourceDTO
    {
        public string? Name {get; set;}
        public string? Description { get; set; }
    }
}