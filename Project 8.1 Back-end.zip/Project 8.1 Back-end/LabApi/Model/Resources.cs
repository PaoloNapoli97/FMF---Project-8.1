namespace LabModel
{
    public class Resources
    {
        public string? Name { get; set; }
        public string? Description { get; set; }
        public Dictionary <string, string> Calendar {get; set;}
        private string? _slot;
        public Resources(string Name, string Description)
        {
            this.Name = Name;
            this.Description = Description;
        }

        public Resources(string Name){
            this.Name = Name;
            Calendar = getCalendar();
        }
        private string[] days = { "Monday", "Tuesday", "Wendsday", "Thursday", "Friday" };
        private string[] hours = { "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00" };
        private Dictionary<string, string> getCalendar()
        {
            Dictionary<string, string> calendar = new();
            _slot = "0";

            foreach (var day in days)
            {
                foreach (var hour in hours)
                {
                    calendar.Add(day + " " + hour, _slot);
                }
            }
            return calendar;
        }
    }
}
