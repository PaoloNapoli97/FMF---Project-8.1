namespace BookingModel
{
    public class Booking
    {
        public string? Id {get; set;}
        public string? Name {get; set;}
        public List<Booking> SavedBookings = new List<Booking>();
        public Booking(string Id, string Name){
            this.Id = Id;
            this.Name = Name;
        }
        public void AddBooking(Booking booking){
            SavedBookings.Add(booking);
        }
        public void DeleteBooking(Booking booking){
            SavedBookings.Remove(booking);
        }
    }
}