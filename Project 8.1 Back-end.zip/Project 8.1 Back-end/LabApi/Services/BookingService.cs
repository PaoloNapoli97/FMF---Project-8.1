using FileManager.Controller;
using BookingModel;
using Newtonsoft.Json;
using LabModel;

namespace BookingServices
{
    public class BookingService
    {
        private const string BookingDb = "BookingDb.json";
        FileManagers fileManagers = new();
        [JsonProperty]
        private List<Booking> bookings = new();

        public void CreateBookingDb()
        {
            fileManagers.CreateFile<Booking>(BookingDb);
        }

        public void WriteBookings(List<Booking> bookings)
        {
            fileManagers.WriteItems(bookings, BookingDb);
        }
        public List<Booking> ReadBookings()
        {
            bookings = fileManagers.ReadItems<Booking>(BookingDb);
            return bookings;
        }
    }
}