using LabModel;

namespace ComputerDTO {

    public class SoftwareAddDTO
    {
        public string? Name {get; set;}
    }
}