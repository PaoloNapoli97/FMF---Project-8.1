namespace LabModel
{
    public class Lab
    {
        public string? Id {get; set;}
        public List<Computer> _computers;
        private List<Resources> _resources;
        public Lab(string Id)
        {
            this.Id = Id;
            this._computers = new();
            this._resources = new();
        }
    }
}