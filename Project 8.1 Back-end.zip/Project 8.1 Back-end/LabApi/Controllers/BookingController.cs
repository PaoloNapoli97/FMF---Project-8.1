using BookingModel;
using BookingServices;
using Microsoft.AspNetCore.Mvc;
using LabServices;

namespace BookingApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]

    public class BookingController : ControllerBase
    {
        BookingService bookingService = new();
        LabService labService = new();

        [HttpGet]
        [Route("")]
        public ActionResult<List<Booking>> GetBooking()
        {
            var bookings = bookingService.ReadBookings();
            return Ok(bookings);
        }

        [HttpPost]
        [Route("Add/Booking/{LabId}/Resource/{ResourceName}/{UserId}/{Day}/{Hour}")]
        public ActionResult ResourcesBooking(string LabId, string ResourceName, string UserId, string Day, string Hour)
        {
            var labs = labService.ReadLabs();
            var lab = labs.FirstOrDefault(x => x.Id == LabId);
            if (lab == null)
            {
                throw new Exception("Lab not found");
            }
            else
            {
                var resource = lab.Resource.FirstOrDefault(x => x.Name == ResourceName);
                if (resource == null)
                {
                    return NotFound();
                }
                else
                {
                    resource.AddBooking(UserId, Day, Hour);
                    Booking booking = new(LabId, UserId, ResourceName);
                    booking.AddBooking(booking);
                    labService.WriteLabs(labs);
                    var pathToUrl = Request.Path.ToString() + '/' + lab.Id;
                    return Created(pathToUrl, resource);
                }
            }
        }

        [HttpPost]
        [Route("Add/Booking/{LabId}/Computer/{ComputerId}/{UserId}/{Day}/{Hour}")]
        public ActionResult ComputerBooking(string LabId, string ComputerId, string UserId, string Day, string Hour)
        {
            var labs = labService.ReadLabs();
            var lab = labs.FirstOrDefault(x => x.Id == LabId);
            if (lab == null)
            {
                throw new Exception("Lab not found");
            }
            else
            {
                var computer = lab.Computers.FirstOrDefault(x => x.Id == ComputerId);
                if (computer == null)
                {
                    return NotFound();
                }
                else
                {
                    computer.AddBooking(UserId, Day, Hour);
                    Booking booking = new(LabId, UserId, ComputerId);
                    labService.WriteLabs(labs);
                    var pathToUrl = Request.Path.ToString() + '/' + lab.Id;
                    return Created(pathToUrl, computer);
                }
            }
        }
    }
}